﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour {

	//void OnTriggerEnter(Collider _col){
	//	Debug.Log (this + " OnTriggerEnter " + _col.name);
	//	if (_col.CompareTag ("Enemy")) {
	//
	//	}
	//}
}
