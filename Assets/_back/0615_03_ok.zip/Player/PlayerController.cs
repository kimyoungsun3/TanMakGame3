﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {
	Vector3 move;
	Transform trans;

	void Start () {
		trans = transform;		
	}
}
