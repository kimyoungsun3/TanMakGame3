﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//[RequireComponent(typeof(PlayerController))]
public class Player : MonoBehaviour {
	public Vector3 offset;
	public Transform[] spawn;
	public Transform bullet;
	public int weaponStep = 1;
	public float weaponDeleyTime = 0.02f;

	Transform trans;
	Plane plane;
	float z, distance, time;
	Ray ray;
	RaycastHit hit;
	Vector3 hitPoint;
	Camera cam;

	void Start () {
		trans 	= transform;
		cam 	= Camera.main;
		z 		= trans.position.z;
		plane 	= new Plane (Camera.main.transform.rotation * Vector3.back, trans.position);
		time 	= Time.time;
	}

	void Update(){
		if (Input.GetMouseButton (0)) {
			ray = cam.ScreenPointToRay (Input.mousePosition);
			if (plane.Raycast (ray, out distance)) {
				hitPoint = ray.GetPoint (distance);
				hitPoint.z = z;
				hitPoint += offset;
				trans.position = hitPoint;

				Shooting ();
			}
		}		
	}

	void Shooting(){

		//Debug.Log(time + ":" + Time.time + ":" + (time > Time.time));
		if (Time.time > time) {
			time = Time.time + weaponDeleyTime;
			switch (weaponStep) {
			case 1:
				PoolManager.ins.Instantiate ("Bullet_Player", spawn [0].transform.position, spawn [0].transform.rotation);
				break;
			case 2:
				PoolManager.ins.Instantiate ("Bullet_Player", spawn [1].transform.position, spawn [1].transform.rotation);
				PoolManager.ins.Instantiate ("Bullet_Player", spawn [2].transform.position, spawn [2].transform.rotation);
				break;
			case 3:
				PoolManager.ins.Instantiate ("Bullet_Player", spawn [0].transform.position, spawn [0].transform.rotation);
				PoolManager.ins.Instantiate ("Bullet_Player", spawn [1].transform.position, spawn [1].transform.rotation);
				PoolManager.ins.Instantiate ("Bullet_Player", spawn [2].transform.position, spawn [2].transform.rotation);
				break;
			case 5:
				PoolManager.ins.Instantiate ("Bullet_Player", spawn [0].transform.position, spawn [0].transform.rotation);
				PoolManager.ins.Instantiate ("Bullet_Player", spawn [1].transform.position, spawn [1].transform.rotation);
				PoolManager.ins.Instantiate ("Bullet_Player", spawn [2].transform.position, spawn [2].transform.rotation);
				PoolManager.ins.Instantiate ("Bullet_Player", spawn [1].transform.position+ Vector3.left, spawn [1].transform.rotation);
				PoolManager.ins.Instantiate ("Bullet_Player", spawn [2].transform.position+ Vector3.right, spawn [2].transform.rotation);
				break;
			}
		}
	}

	/*
	//Keyboard move
	public float speedMove;
	//PlayerController controller;
	Vector3 moveDir;
	float h, v, z;
	void Move(){
		h = Input.GetAxisRaw ("Horizontal");
		v = Input.GetAxisRaw ("Vertical");
		if (h != 0 || v != 0) {
			moveDir.Set (h, v, 0);
			trans.Translate( moveDir.normalized * speedMove * Time.deltaTime);
		}
	}
	*/
}
