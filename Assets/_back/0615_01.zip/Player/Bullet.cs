﻿#define DEBUG_VIEW
using UnityEngine;
using System.Collections;

public class Bullet : MonoBehaviour {
	public LayerMask checkMask;
	public float timePoolReturnTime = 2f;
	public float moveSpeed 	= 40f;
	int damage 		= 1;
	//public GameObject explosion;
	//int playerNumber = 1;
	//GameObject owner;
	Ray ray;
	Transform trans;
	GameObject go;
	RaycastHit hit;
	float moveDistance;
	Vector3 oldPosition;
	public float bulletRadius = 0.15f;
	//Vector3 moveDir = Vector3.up;
	void Awake(){
		Debug.Log (this + "Awake");
	}

	void Start(){
		Debug.Log (this + "Start");
	}

	public void SetInit(){
		//moveSpeed = _speed;
		trans 		= transform;
		go 			= gameObject;
	}

	//public void SetDir(Vector3 _dir){
	//	moveDir = _dir;
	//}

	void Update(){
		Debug.Log (this + "Update");
		ray.origin 		= trans.position;
		ray.direction 	= trans.up;

		moveDistance = moveSpeed * Time.deltaTime;
		#if DEBUG_VIEW
		Debug.DrawLine (transform.position, transform.position + transform.forward * moveDistance, Color.red);
		#endif
		if (Physics.Raycast (ray, out hit, moveDistance, checkMask, QueryTriggerInteraction.Collide)) {
			HitAttack ();
		}

		#if !DEBUG_VIEW
			transform.Translate (Constant.up * moveDistance);
		#else
			oldPosition = transform.position;
			transform.Translate (Constant.up * moveDistance);
			Debug.DrawLine (oldPosition, transform.position, Color.red);
		#endif

	}

	void HitAttack(){
		//EnemyHealth _scp = hit.collider.GetComponent<EnemyHealth> ();
		//if (_scp != null) {
		//	_scp.TakeDamage (damage);
		//}	

		//Sound, Particle
		//ParticleSystem _p = PoolManager.ins.Instantiate("ShellExplosion", hit.point, Quaternion.identity).GetComponent<ParticleSystem>();
		//_p.Stop ();
		//_p.Play ();

		//SoundManager.ins.Play ("ShellExplosion", -1);
		ReturnPool ();
	}

	//----------------------------
	int nEnableCount = 0;
	void OnEnable(){
		Debug.Log (this + "OnEnable:" + nEnableCount);
		if (nEnableCount > 0) {
			Collider[] _cols = Physics.OverlapSphere (transform.position, bulletRadius, checkMask);
			if (_cols.Length > 0) {
				Debug.Log (" > ");
				HitAttack ();
			} else {
				CancelInvoke ();
				Invoke ("ReturnPool", timePoolReturnTime);
			}
		} else {
			nEnableCount++;
		}
	}

	void OnDisalbe(){
		Debug.Log (this + "OnDisalbe");
		CancelInvoke ();
	}

	void OnBecameInvisible(){
		Debug.Log (this + "OnBecameInvisible");
		Debug.Log (go.activeSelf + ":" + go.activeInHierarchy);
		if (go.activeSelf) {
			Debug.Log (" > ");
			ReturnPool ();
		}
	}

	void ReturnPool(){		
		Debug.Log (this + "ReturnPool");
		CancelInvoke ();
		gameObject.SetActive (false);
	}

	//-----------------------------
	#if DEBUG_VIEW
	void OnDrawGizmos(){
		Gizmos.DrawWireSphere(transform.position, bulletRadius);
	}
	#endif
}