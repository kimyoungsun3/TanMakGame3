﻿//#define DEBUG_VIEW
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#if DEBUG_VIEW
using UnityEditor;
#endif

public class Projectile : MonoBehaviour {
	public LayerMask mask;
	Transform trans;
	float speed = 10f;
	float nextTime, moveDistance, damage;
	//Ray ray;
	RaycastHit hit;
	Vector3 nextPoint;
	float skinWidth = .1f;
	TrailRenderer trailRenderer;

	void Awake(){
		trans 			= transform;
		trailRenderer 	= GetComponent<TrailRenderer> ();
	}

	/*
	public void SetSpeed(float _speed, float _damage){
		nextTime 	= Time.time + Constant.BULLET_ALIVE_TIME;
		speed 		= _speed;
		damage 		= _damage;

		moveDistance = speed * Time.deltaTime;
		Collider[] _cols = Physics.OverlapSphere (trans.position, moveDistance, mask);
		if (_cols.Length > 0) {
			OnHitObject (_cols[0], trans.position);
		}
		//for (int i = 0, iMax = _cols.Length; i < iMax; i++) {
		//	OnHitObject (_cols[i], trans.position);
		//}
	}

	void Update () {
		//moveDistance = speed * Time.deltaTime;
		//ray.origin = trans.position;
		//ray.direction = trans.forward;

		////현시점에서 매순간 지속적인 검사를 실행한다...
		////애도 통과 된 후에는 검사 안함....
		//if (Physics.Raycast (ray, out hit, moveDistance + skinWidth, mask, QueryTriggerInteraction.Collide)) {
		//	OnHitObject (hit.collider);
		//	return;
		//}	

		//현시점에서 매순간 지속적인 검사를 실행한다...
		//애도 통과 된 후에는 검사 안함....
		moveDistance = speed * Time.deltaTime;
		nextPoint = trans.position + trans.forward * (moveDistance + skinWidth);
		if(Physics.Linecast(trans.position, nextPoint, out hit, mask, QueryTriggerInteraction.Collide)){
			OnHitObject (hit.collider, hit.point);
			return;
		}		

		trans.Translate (Vector3.forward * moveDistance);
		if(Time.time > nextTime){
			Destroy ();
		}

		#if DEBUG_VIEW
		Debug.DrawRay(trans.position, trans.forward * moveDistance);
		if (Input.GetMouseButtonUp (0)) {
			EditorApplication.isPaused = true;
		}
		#endif
	}

	void OnHitObject(Collider _col, Vector3 _hitPoint){
		//Debug.Log (hit.collider.gameObject.name);
		IDamageable _scp = _col.GetComponent<IDamageable>();
		if (_scp != null) {
			_scp.TakeHit (damage, _hitPoint, trans.forward);
		}
		Destroy ();
	}

	void Destroy(){
		trailRenderer.Clear ();
		//base.Destroy ();
		gameObject.SetActive(false);
	}

	//void OnDrawGizmosSelected(){
	//	//Gizmos.color = Color.red;
	//	//Gizmos.DrawWireSphere (transform.position, radius);
	//}
	*/
}
